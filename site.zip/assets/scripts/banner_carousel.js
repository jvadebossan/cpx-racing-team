$(document).ready(function(){
    $('.single-item').slick({
        arrows: false,
        autoplay: true,
        autoplaySpeed: 2000

    })
})